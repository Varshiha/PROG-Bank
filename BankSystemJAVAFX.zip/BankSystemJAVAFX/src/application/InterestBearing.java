package application;

public interface InterestBearing {
	
	public abstract void applyInterest(Client client);

}
