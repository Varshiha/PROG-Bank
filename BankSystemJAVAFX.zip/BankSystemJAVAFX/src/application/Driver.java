/*package application;
import java.util.ArrayList;

public class Driver {

	public static void main(String[] args) {
		try {
			ArrayList<Client> clients = FileManager.loadClients();
			ArrayList<Account> accounts = FileManager.loadAccounts(clients);
			FileManager.loadTransactions(accounts);

			if(clients == null) {
				clients = new ArrayList<>();
			}
			if(accounts == null) {
				accounts = new ArrayList<>();
			}
			
			FileManager.saveClients(clients);
			FileManager.saveAccounts(accounts);
			FileManager.saveTransactions(accounts);
			
			//Main.main(args);

		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
*/