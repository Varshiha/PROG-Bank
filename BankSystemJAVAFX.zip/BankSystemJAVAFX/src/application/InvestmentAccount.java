package application;
import java.time.LocalDate;

public class InvestmentAccount extends Account implements Maintainable, InterestBearing{

	private double interestRate = 0.05;
	protected static int counter = 100;
	
	public InvestmentAccount(Client client) {
		super(client);
		this.accountNo = "INV"+ counter;
		counter = counter+15;
		this.type = "Investment";
	}
	@Override
	public void withdraw(double amount) {
		throw new UnsupportedOperationException("Direct withdrawals from an Investment account are forbidden.");
	}

	public void transferToChequing(ChequingAccount accountNo, double amount) throws InvestmentLockException, InsufficientFundsException {
		LocalDate temp = LocalDate.parse(openDate);
		LocalDate date = LocalDate.now();
		if(temp.isBefore(date.minusYears(1)) == false) {
			throw new InvestmentLockException("Transfer not successful because Investment account has not been open for more than 1 year.");
		}
		
		super.withdraw(amount);
		accountNo.deposit(amount, "Deposited from investment");
	}
	@Override
	public void applyMonthlyFee(Client client) {
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		} 
		
		withdraw(10);
	}

	@Override
	public void applyInterest(Client client) {
		double interest = getBalance()*interestRate;
		if(client instanceof VIPClient) {
			VIPClient vip = (VIPClient) client;
			interest = interest + (getBalance()*vip.getBonusInterest());
		}
		deposit(interest, "Interest applied");
	}
	

}
