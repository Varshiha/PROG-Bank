package application;

public class SavingsAccount extends Account implements Maintainable, InterestBearing{

	private double interestRate = 0.02;
	protected static int counter = 100;
	
	public SavingsAccount(Client client) {
		super(client);
		this.accountNo = "SAV"+ counter;
		counter = counter+15;
		this.type = "Savings";
	}

	@Override
	public void applyMonthlyFee(Client client) throws InsufficientFundsException {
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		} 
		
		withdraw(10);
	}

	@Override
	public void applyInterest(Client client) {
		double interest = getBalance()*interestRate;
		
		if(client instanceof VIPClient) {
			VIPClient vip = (VIPClient) client;
			interest = interest + (getBalance()*vip.getBonusInterest());
		}
		
		deposit(interest, "Interest applied");
	}
	

}
