package application;

public class StudentClient extends StandardClient{

	public StudentClient(String username, String password) {
		super(username, password);
		this.type = "Student";
	
	}

}
