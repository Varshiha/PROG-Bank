package application;

public class IndividualClient extends StandardClient {

	public IndividualClient(String username, String password) {
		super(username, password);
		this.type = "Individual";
	}

}
