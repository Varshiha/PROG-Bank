package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
public class LoginController {
	@FXML
	private TextField usernameField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private Label messageLabel;
	
	@FXML
	private void enter(ActionEvent event) throws IOException, InsufficientFundsException {
		String user = usernameField.getText();
		String pass = passwordField.getText();
		
		Username.clients = FileManager.loadClients();
		Username.accounts = FileManager.loadAccounts(Username.clients);
		FileManager.loadTransactions(Username.accounts);
		
		
		boolean found = false;
		int clientid = 0;
		
		for(Client c : Username.clients) {
			if(c.getUsername().equals(user) && c.getPassword().equals(pass)) {
				found = true;
				Username.currentClient = c;
				c.applyMonthlyUpdates();
				clientid = c.getClientID();
				break;
			}
		}
		
		if(found) {
			Username.currentUsername = usernameField.getText();
			Username.currentClientID = clientid;
			messageLabel.setText("Login Succesfull");
			Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		}else {
			messageLabel.setText("Invalid username or password. Try again!");
		}
		
	}
	
	@FXML
	private void goBackSignUp(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(new Scene(root));
		stage.show();
	}

}
