package application;

public class PremiumClient extends Client{

	public PremiumClient(String username, String password) {
		super(username, password);
	}

}
