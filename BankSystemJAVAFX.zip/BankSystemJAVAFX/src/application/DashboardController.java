package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DashboardController {
	private Account selectedAccount;
	@FXML private Label welcomeName;
	@FXML private Button close;
	@FXML private Button logout;
	@FXML private AnchorPane createAccountPane;
	@FXML private ListView<Account> accountsList;
	@FXML private TextArea accountInfo;
	@FXML private ListView<Transaction> transactionsList;
	@FXML private TextField amountField;
	@FXML private TextField reasonField;
	@FXML private ComboBox<Account> fromAccountCombo;
	@FXML private ComboBox<Account> toAccountCombo;
	@FXML private TextField amountTransfer;
	@FXML private AnchorPane transferPane;




	
	
	 public void initialize() {
		 try {
			    welcomeName.setText("Welcome, " + Username.currentUsername);
			    
				
				
				System.out.println("USERNAME" + Username.currentClient.getAccounts().size());
				
				transactionsList.setVisible(false);
				close.setVisible(false);
				 
			}catch (Exception e) {
				e.printStackTrace();
			}
	 }
	 
		
	@FXML
	public void goToAccounts() throws IOException {
		
		accountsList.getItems().clear();

		for(Account acc : Username.accounts) {
			if(acc.getClientID() == Username.currentClientID) {
				accountsList.getItems().add(acc);
			}
		}
		
	}
	@FXML
	private void handleAccountClick(MouseEvent event) {
		
		accountInfo.setVisible(true);
		transactionsList.setVisible(true);
		close.setVisible(true);
		
		selectedAccount = accountsList.getSelectionModel().getSelectedItem();
		if(selectedAccount == null) return;
		
		accountInfo.setText(selectedAccount.getFullInfo());
		transactionsList.getItems().setAll(selectedAccount.getTransactions());
	}
	
	@FXML
	public void handleDeposit() {
		try {
			
			double amount = Double.parseDouble(amountField.getText());
			if(selectedAccount == null || amount <= 0) return;
			
			
			String reason = reasonField.getText();
			if(reason == null || reason.isBlank()) {
				selectedAccount.deposit(amount);
			}else {
				selectedAccount.deposit(amount, reason);
			}
			
			
			
			//refresh
			FileManager.saveClients(Username.clients);
			 FileManager.saveAccounts(Username.accounts);
			 FileManager.saveTransactions(Username.accounts);
			accountInfo.setText(selectedAccount.getFullInfo());
			transactionsList.getItems().setAll(selectedAccount.getTransactions());
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void handleWithdraw() {
        try {
			
			double amount = Double.parseDouble(amountField.getText());
			if(selectedAccount == null) return;
			
			
			String reason = reasonField.getText();
			if(reason == null || reason.isBlank()) {
				reason = "Withdraw";
			}
			
		try {
			selectedAccount.withdraw(amount);
		
        } catch (InsufficientFundsException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
        } catch (IllegalArgumentException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
        } catch(UnsupportedOperationException e) {
        	Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
        }
			//refresh
			FileManager.saveClients(Username.clients);
			 FileManager.saveAccounts(Username.accounts);
			 FileManager.saveTransactions(Username.accounts);
			accountInfo.setText(selectedAccount.getFullInfo());
			transactionsList.getItems().setAll(selectedAccount.getTransactions());
			
		}catch (Exception e) {
			e.printStackTrace();
		}		
	}
	@FXML
	public void closeAccounts() {
		accountInfo.setVisible(false);
		transactionsList.setVisible(false);
		close.setVisible(false);
	}
	@FXML
	private void openTransferPane(ActionEvent e) {
		transferPane.setVisible(true);

		fromAccountCombo.getItems().clear();
		toAccountCombo.getItems().clear();
		
		for(Account acc : Username.accounts) {
			if(acc.getClientID() == Username.currentClientID) {
				fromAccountCombo.getItems().add(acc);
				toAccountCombo.getItems().add(acc);
			}
		}
		



	}
	
	@FXML
	private void closeTranserPane() {
		transferPane.setVisible(false);
		
		amountTransfer.clear();
		fromAccountCombo.getSelectionModel().clearSelection();
		toAccountCombo.getSelectionModel().clearSelection();
		
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("Success");
		alert.setContentText("Transfer Successful"); 



	}
	@FXML
	public void handleConfirmTransfer(ActionEvent e) throws IOException {
		try {
			
			
			//if(fromAccountCombo.getValue()== null || toAccountCombo.getValue() == null) {
			//	 throw new IllegalArgumentException("One of the account were not selected");
			 //}
		
			Account from = fromAccountCombo.getValue();
			Account to = toAccountCombo.getValue();
			System.out.println("STEP 2");
			double amount = Double.parseDouble(amountTransfer.getText());
			
			
			System.out.println(Username.currentClient.getAccounts());
			
			if(from == to) {
				throw new IllegalArgumentException("Cannot transfer to the same account");
			}
			
			if(from instanceof InvestmentAccount && to instanceof ChequingAccount) {
				((InvestmentAccount) from).transferToChequing((ChequingAccount)to, amount);
			}else if((from instanceof InvestmentAccount && to instanceof SavingsAccount)) {
				throw new IllegalArgumentException("Can' transfer from savings to chequing");
			}else if((from instanceof InvestmentAccount && to instanceof InvestmentAccount) ){
				throw new IllegalArgumentException("Can' transfer from investment to chequing");
			}else {
			Username.currentClient.transfer(from.getAccountNo(), to.getAccountNo(), amount);
			}
			
			//refresh
			FileManager.saveClients(Username.clients);
			 FileManager.saveAccounts(Username.accounts);
			 FileManager.saveTransactions(Username.accounts);
			
			transferPane.setVisible(false);
			
		}catch (IllegalArgumentException ex) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle(null);
			alert.setHeaderText(null);
			alert.setContentText(ex.getMessage()); 
        } catch (InsufficientFundsException e1) {
        	Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e1.getMessage()); 
		} catch (InvestmentLockException e1) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Investment Lock Exception");
			alert.setHeaderText(null);
			alert.setContentText(e1.getMessage()); 
		}
	} 

	
	/*
	 ===========================================================================================================
	                                   CREATE ACCOUNT
	 ===========================================================================================================

	 */
	@FXML
	public void goToCreateAccount() {
		createAccountPane.setVisible(true);
	}
	
	@FXML
	private void createAccount(ActionEvent event) {
		try {
			Button clickedButton = (Button) event.getSource();
		    String id = clickedButton.getId();
		
		    Client client =  Username.currentClient;
		
		    Account newAccount = null;
		
			newAccount = client.openAccount(id);

			if(newAccount != null) {
				client.accounts.add(newAccount);
				Username.accounts.add(newAccount);
			}
			
			FileManager.saveAccounts(Username.accounts);
			goToAccounts();
			createAccountPane.setVisible(false);
		} catch (MissingChequingAccountException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	
	}
	/*
	 ===========================================================================================================
	                                   LOGOUT
	 ===========================================================================================================

	 */
	
	@FXML
	public void logout(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(new Scene(root));
		stage.show();
	}

}
