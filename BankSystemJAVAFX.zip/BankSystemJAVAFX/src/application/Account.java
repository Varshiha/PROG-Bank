package application;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Account{
	protected String accountNo;
	protected double balance;
	protected String openDate; 
	protected int clientID;
	protected ArrayList<Transaction> transactions;
	protected String type;

	public Account(Client client) {
		this.balance = 0;
		this.openDate = LocalDate.now().toString();
		this.clientID = client.getClientID();
		this.transactions = new ArrayList<>();
		
	}
	
	public void deposit(double amount) {
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		balance += amount;
		addTransaction(new Transaction("DEPOSIT", amount, accountNo, "Deposit"));
	}
	
	public void deposit(double amount, String description) {
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		balance += amount;
		addTransaction(new Transaction("DEPOSIT", amount, accountNo, description));
	}
	
	public void withdraw(double amount) throws InsufficientFundsException, IllegalArgumentException{
		
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		
		if(amount > balance) {

			throw new InsufficientFundsException("Amount withdrawn must less than the balance");
		}
		
		balance -= amount;
		
		addTransaction(new Transaction("WITHDRAW", amount, accountNo, "Withdrawal"));
	}

	public void addTransaction(Transaction t) {
		if(t != null) {
			transactions.add(t);
		}
		
	}

	public String getAccountNo() {
		return accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public String getOpenDate() {
		return openDate;
	}


	public int getClientID() {
		return clientID;
	}

	public void setClientID(int clientID) {
		this.clientID = clientID;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}
	public String getFullInfo() {
		return "Account Type: " + type + 
			   "\nAccountNo: " + accountNo + 
			   "\nBalance: " + balance + 
			    "\nOpenDate: " + openDate;
				   //"\nClient: " + clientID + 
				 //"\nTransactions=" + transactions;
			}

	@Override
	public String toString() {
		return type + " : $" + balance;

	}

	public String getType() {
		return type;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
		
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	
	public void applyInterest(Client client) {}
	public void applyMonthlyFee(Client client) throws InsufficientFundsException {}

	

}
