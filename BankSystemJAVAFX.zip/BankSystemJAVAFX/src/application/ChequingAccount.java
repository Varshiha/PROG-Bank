package application;

public class ChequingAccount extends Account implements Maintainable{

	protected static int counter = 100;
	
	public ChequingAccount(Client client) {
		super(client);
		this.accountNo = "CHE"+ counter;
		counter = counter+15;
		this.type = "Chequing";
	}
	@Override
	public void applyMonthlyFee(Client client) throws InsufficientFundsException {
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		} 
		
		withdraw(10);
		
	}

}
