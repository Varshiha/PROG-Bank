package application;

public interface Maintainable {
	
	public abstract void applyMonthlyFee(Client client) throws InsufficientFundsException;

}
